﻿using System;
using System.Text.RegularExpressions;

public class RegMarkLib
{
    private static readonly string validPattern = @"^[ABEKMHOPCTYX]\d{3}[ABEKMHOPCTYX]{2}\d{2,3}$";
    private static readonly string letters = "ABEKMHOPCTYX";
    private static readonly int minRegion = 1;
    private static readonly int maxRegion = 199;

    public static bool CheckMark(string mark)
    {
        if (!Regex.IsMatch(mark, validPattern)) return false;
        int region = int.Parse(mark.Substring(mark.Length - 3));
        return region >= minRegion && region <= maxRegion;
    }

    public static string GetNextMarkAfter(string mark)
    {
        if (!CheckMark(mark)) throw new ArgumentException("Invalid mark format");

        char firstLetter = mark[0];
        int number = int.Parse(mark.Substring(1, 3));
        string lastTwoLetters = mark.Substring(4, 2);
        int region = int.Parse(mark.Substring(mark.Length - 3));

        number++;
        if (number > 999)
        {
            number = 0;
            lastTwoLetters = IncrementLetters(lastTwoLetters);
            if (lastTwoLetters == "AA")
            {
                firstLetter = IncrementLetter(firstLetter);
            }
        }

        return string.Format("{0}{1:D3}{2}{3:D3}", firstLetter, number, lastTwoLetters, region);
    }

    public static string GetNextMarkAfterInRange(string prevMark, string rangeStart, string rangeEnd)
    {
        string nextMark = GetNextMarkAfter(prevMark);
        return (string.Compare(nextMark, rangeStart, StringComparison.Ordinal) >= 0 && string.Compare(nextMark, rangeEnd, StringComparison.Ordinal) <= 0)
            ? nextMark : "out of stock";
    }

    public static int GetCombinationsCountInRange(string mark1, string mark2)
    {
        return Math.Max(0, string.Compare(mark2, mark1, StringComparison.Ordinal));
    }

    private static string IncrementLetters(string letters)
    {
        int index1 = RegMarkLib.letters.IndexOf(letters[0]);
        int index2 = RegMarkLib.letters.IndexOf(letters[1]);

        if (index2 < RegMarkLib.letters.Length - 1)
            return letters[0].ToString() + RegMarkLib.letters[index2 + 1];
        else if (index1 < RegMarkLib.letters.Length - 1)
            return RegMarkLib.letters[index1 + 1] + "A";
        else
            return "AA"; // Reset if overflow
    }

    private static char IncrementLetter(char letter)
    {
        int index = RegMarkLib.letters.IndexOf(letter);
        return index < RegMarkLib.letters.Length - 1 ? RegMarkLib.letters[index + 1] : 'A';
    }
}
